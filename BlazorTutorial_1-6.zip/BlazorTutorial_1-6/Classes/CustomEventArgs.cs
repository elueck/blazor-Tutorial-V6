﻿using Microsoft.AspNetCore.Components.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorTutorial_1.Classes
{
    //PointerEventArgs
    public class InfoEvent
    {
        public bool EventTriggered { get; set; }
    }
}